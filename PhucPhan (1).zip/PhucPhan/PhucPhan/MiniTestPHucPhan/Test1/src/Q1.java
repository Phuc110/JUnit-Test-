import java.util.Arrays;
import java.util.Scanner;

public class Q1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        StringBuilder sb = new StringBuilder();
        int T = sc.nextInt();

        for (int i = 0; i < T; i++) {

            int n = sc.nextInt();
            int[] array = new int[n];
            for (int j = 0; j < n; j++) {
                array[j] = sc.nextInt();
            }
            Arrays.sort(array);
            if ( array[0] < array[1]) {
                sb.append(array[0]).append(" ");
            }
            for (int j = 1; j <= n - 2; j++) {
                if (array[j - 1] < array[j] && array[j] < array[j + 1]) {
                    sb.append(array[j]).append(" ");

                }
            }

            if (array[n - 2] < array[n - 1]) {
                sb.append(array[n - 1]).append(" ");

            }
            sb.append("\n");

        }
        System.out.println(sb);
    }
}
