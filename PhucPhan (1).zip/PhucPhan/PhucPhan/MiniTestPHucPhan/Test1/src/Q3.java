import java.util.Scanner;

public class Q3 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        StringBuilder sb = new StringBuilder();
        int N = scanner.nextInt();
        int K = scanner.nextInt();
        int[] array = new int[N];
        for (int i = 0; i < N; i++) {
            array[i] = scanner.nextInt();
        }
        int max = 0;
        for (int i = 0; i <N; i++) {
            if (array[i] > max  ) {
                max = array[i];
                break;
            }

        }
        System.out.println(max);
    }

}
