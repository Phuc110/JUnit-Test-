import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Q3 {
    public static void main(String[] args) {
        var sc = new Scanner(System.in);
        var sb = new StringBuilder();
        var nOStudent = sc.nextInt();
        ArrayList<Student> stuList = new ArrayList<>();
        for (int i = 0; i < nOStudent; i++) {
            String name = sc.next();
            Student student = new Student(name);

            int nOCourses = sc.nextInt();
            for (int j = 0; j < nOCourses; j++) {
                int credit = sc.nextInt();
                int grade = sc.nextInt();
                student.addGrade(grade, credit);
            }

            stuList.add(student);
        }
        stuList.sort((s1, s2) -> {
            int compare = Double.compare(s2.avg, s1.avg);
            if (compare == 0) {
                compare = Integer.compare(s2.totalCredit, s1.totalCredit);
            }
            if (compare == 0) {
                compare = s1.name.compareTo(s2.name);
            }
            return compare;
        });
        for (Student s : stuList) {
            sb.append(s).append("\n");
        }
        System.out.println(sb);
    }

    static class Student {
        String name;
        int totalCredit = 0;
        double avg = 0;
        double totalGrade = 0;

        public Student(String name) {
            this.name = name;
        }

        public void addGrade(int grade, int credit) {
            if (grade >= 50) {
                totalCredit += credit;
                totalGrade += credit * grade;
                avg = totalGrade / totalCredit;
            }
        }

        @Override
        public String toString() {
            return name + " " + totalCredit + " " + Math.round(avg);
        }

    }
}
