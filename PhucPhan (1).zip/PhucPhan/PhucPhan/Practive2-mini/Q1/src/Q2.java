import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Q2 {
    public static void main(String[] args) {
        var sc = new Scanner(System.in);
        var sb = new StringBuilder();
        var nOStudent = sc.nextInt();
        for (int i = 0; i < nOStudent; i++) {
            String name = sc.next();
            Student student = new Student(name);

            int nOCourses = sc.nextInt();
            for (int j = 0; j < nOCourses; j++) {
                int grade = sc.nextInt();
                student.addGrade(grade);
            }
            sb.append(student).append(" \n");

        }
        System.out.println(sb);
    }

    static class Student {
        String name;
        int totalCredit;

        public Student(String name) {
            this.name = name;
        }

        public void addGrade(int grade) {
            if (grade >= 50) {
                totalCredit += 4;
            }
        }

        @Override
        public String toString() {
            return name + " " + totalCredit;
        }

    }
}
