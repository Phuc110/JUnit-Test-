import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Q1 {
    public static void main(String[] args) {
        var sc = new Scanner(System.in);
        var sb = new StringBuilder();
        int n = sc.nextInt();
        int m = sc.nextInt();
        Map<String, String> wordMap = new HashMap<>();
        for (int i = 0; i < m; i++) {
            String wordA = sc.next();
            String wordB = sc.next();
            wordMap.put(wordA, wordB);
        }
        var list = new ArrayList<String>();
        for (int i = 0; i < n; i++) {
            list.add(sc.next());
        }
        for (String e : list) {
            if (e.length() > wordMap.get(e).length()) {
                sb.append(wordMap.get(e)).append(" ");

            } else {
                sb.append(e).append(" ");
            }
        }
        System.out.println(sb);
    }
}
