import java.util.Arrays;
import java.util.Scanner;

public class EIEVERYN // Every Number
{
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        StringBuilder sb = new StringBuilder();

        int testcases = scanner.nextInt();
        for (int t = 0; t < testcases; t++) {
            int m = scanner.nextInt();
            int n = scanner.nextInt();
            int[] array = new int[m];
            boolean flagl = false;
            boolean flagn = false;
            boolean flag = true;
            for (int j = 0; j < m; j++) {
                array[j] = scanner.nextInt();
            }
            Arrays.sort(array);
            for (int i = 0; i < array.length; i++) {
                if (array[i] == 1) {

                }

            }

        }

    }
}
