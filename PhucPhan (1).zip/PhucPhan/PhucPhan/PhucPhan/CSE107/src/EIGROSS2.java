import java.util.Scanner;

public class EIGROSS2 {
    public static void main(String[] args) {
        var sc = new Scanner(System.in);
        var sb = new StringBuilder();
        var netSalary = sc.nextLong();
        var newsalary = netSalary - 11000000;
        var totalSalary = 0;
        if (netSalary <= 11000000) {
            sb.append(netSalary);
        }
        var taxable = new long[] { 5000000, 10000000, 18000000, 32000000, 52000000, 80000000, Long.MAX_VALUE };
        double[] rate = { 0.05, 0.10, 0.15, 0.20, 0.25, 0.30, 0.35 };
        var currentNet = 0.0;
        var currentGross = 0.0;

        for (int i = 0; i < taxable.length; i++) {
            var level = currentNet + (taxable[i + 1] - taxable[i]) * (1 - rate[i]);

            if (level <= netSalary) {
                currentGross = taxable[i];
                currentNet = level;

            } else {
                currentGross += (taxable[i + 1] - taxable[i]) * (1 - rate[i]);
                break;
            }

        }
        currentGross += (netSalary - currentNet);
        sb.append(currentGross + 11000000);

        System.out.println(sb);
    }

}
