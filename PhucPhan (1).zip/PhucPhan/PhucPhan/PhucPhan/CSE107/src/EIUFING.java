import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import java.util.StringTokenizer;

public class EIUFING {
    static InputReader rd = new InputReader(System.in);
    static StringBuilder sb = new StringBuilder();

    public static void main(String[] args) {
        int numOfFingers = rd.nextInt();
        int fingerIndex = numOfFingers % 18;
        if (fingerIndex > 10) {
            fingerIndex = 20 - fingerIndex;
        }

        String[] fingers = { "cai", "tro ", "giua", "ap ut", "ut", "ut", "ap ut", "giua", "tro", "cai" };
        String[] side = { "trai", "phai" };
        String hand;
        if (fingerIndex <= 5) {
            hand = side[0];

        } else {
            hand = side[1];
        }
        String finger = fingers[numOfFingers - 1];
        sb.append("Ngon ").append(finger).append(" cua ban tay ").append(hand).append("\n");
        System.out.println(sb);

    }

    static class InputReader {
        StringTokenizer tokenizer;
        BufferedReader reader;
        String token;
        String temp;

        public InputReader(InputStream stream) {
            tokenizer = null;
            reader = new BufferedReader(new InputStreamReader(stream));
        }

        public InputReader(FileInputStream stream) {
            tokenizer = null;
            reader = new BufferedReader(new InputStreamReader(stream));
        }

        public String nextLine() throws IOException {
            return reader.readLine();
        }

        public String next() {
            while (tokenizer == null || !tokenizer.hasMoreTokens()) {
                try {
                    if (temp != null) {
                        tokenizer = new StringTokenizer(temp);
                        temp = null;
                    } else {
                        tokenizer = new StringTokenizer(reader.readLine());
                    }
                } catch (IOException e) {
                }
            }
            return tokenizer.nextToken();
        }

        public double nextDouble() {
            return Double.parseDouble(next());
        }

        public int nextInt() {
            return Integer.parseInt(next());
        }

        public long nextLong() {
            return Long.parseLong(next());
        }
    }
}
