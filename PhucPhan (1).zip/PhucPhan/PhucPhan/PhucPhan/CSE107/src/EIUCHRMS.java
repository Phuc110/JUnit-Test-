import java.util.Scanner;

public class EIUCHRMS {
    public static void main(String[] args) {
        var sc = new Scanner(System.in);
        var sb = new StringBuilder();
        long[] money = { 2000000, 5000000, 10000000, 20000000, 50000000, 100000000, 200000000, Long.MAX_VALUE };
        double[] rate = { 3, 4, 5, 6, 7, 8, 9, 10 };
        var nOBill = sc.nextInt();
        var total = 0;
        var discunt = 0;
        var totalAll = 0;
        for (int i = 0; i < nOBill; i++) {

            long billValue = sc.nextLong();
            var bill = Math.min(billValue, money[i]);
            discunt += bill * (rate[i] / 100);
            total += billValue - discunt;
            totalAll += total;

        }
        sb.append(totalAll);
        System.out.println(sb);
    }
}