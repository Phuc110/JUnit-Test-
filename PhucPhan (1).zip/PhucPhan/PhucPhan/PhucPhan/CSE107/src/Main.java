import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        StringBuilder sb = new StringBuilder();

        int n = scanner.nextInt();

        double[] salaries = new double[n];

        double totalRegularHours = 0;
        double totalOvertimeHours = 0;
        double totalRegularPay = 0;
        double totalOvertimePay = 0;

        for (int i = 0; i < n; i++) {
            double regularHours = 0;
            double overtimeHours = 0;
            double overtimePay = 0;

            double[] hours = new double[5];
            for (int j = 0; j < 5; j++) {
                hours[j] = scanner.nextDouble();
            }
            double wage = scanner.nextDouble();

            double totalSalary = 0;
            for (int j = 0; j < 5; j++) {
                double workedHours = hours[j];

                if (workedHours > 8) {
                    regularHours += 8;
                    overtimeHours += (workedHours - 8);
                    overtimePay += (workedHours - 8) * wage * 1.5;
                } else {
                    regularHours += workedHours;
                }
            }

            double regularPay = regularHours * wage;
            totalSalary = regularPay + overtimePay;
            salaries[i] = totalSalary;

            totalRegularPay += regularPay;
            totalOvertimePay += overtimePay;
            totalRegularHours += regularHours;
            totalOvertimeHours += overtimeHours;
        }

        for (double salary : salaries) {
            sb.append(Math.round(salary));
        }

        double avgOfficeHourSalary = totalRegularHours > 0 ? totalRegularPay / totalRegularHours : 0.0;

        double avgOvertimePay = totalOvertimeHours > 0 ? totalOvertimePay / totalOvertimeHours : 0.0;

        sb.append(Math.round(avgOfficeHourSalary));
        sb.append(Math.round(avgOvertimePay));
        System.out.println(sb);

        
    }
}
