import java.util.Scanner;

class Salary2 {

    static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {

        StringBuilder sb = new StringBuilder();

        int n = sc.nextInt();

        double totalOfficeHour = 0;
        double totalOvertimeHour = 0;
        double totalOfficeSalary = 0;
        double totalOvertimeSalary = 0;
        double totalSalary = 0;

        for (int i = 0; i < n; i++) {

            double officeHour = 0;
            double overtimeHour = 0;

            for (int j = 0; j < 5; j++) {

                double hour = sc.nextDouble();
                officeHour += Math.min(hour, 8);
                overtimeHour += Math.max(hour - 8, 0);
            }

            double salary = sc.nextDouble();

            totalSalary = officeHour * salary + overtimeHour * salary * 1.5;

            totalOfficeHour += officeHour;
            totalOvertimeHour += overtimeHour;

            totalOfficeSalary += officeHour * salary;
            totalOvertimeSalary += overtimeHour * salary * 1.5;
            sb.append((double) Math.round(totalSalary * 100) / 100).append("\n");
        }
        sb.append((double) Math.round((totalOfficeSalary / totalOfficeHour) * 100) / 100).append("\n");
        sb.append((double) Math.round((totalOvertimeSalary / totalOvertimeHour) * 100) / 100).append("\n");
        System.out.println(sb);
    }
}
