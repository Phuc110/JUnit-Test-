import java.util.Scanner;

public class EIUSALESTest {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        long doanhSo = sc.nextLong();

        double tienThuong = 0.0;

        if (doanhSo > 0) {
            long thuNhapBac1 = Math.min(doanhSo, 20);
            tienThuong += thuNhapBac1 * 0.02;
            doanhSo -= thuNhapBac1;
        }

        if (doanhSo > 0) {
            long thuNhapBac2 = Math.min(doanhSo, 30);
            tienThuong += thuNhapBac2 * 0.03;
            doanhSo -= thuNhapBac2;
        }

        if (doanhSo > 0) {
            long thuNhapBac3 = Math.min(doanhSo, 150);
            tienThuong += thuNhapBac3 * 0.04;
            doanhSo -= thuNhapBac3;
        }

        if (doanhSo > 0) {
            long thuNhapBac4 = Math.min(doanhSo, 300);
            tienThuong += thuNhapBac4 * 0.05;
            doanhSo -= thuNhapBac4;
        }

        if (doanhSo > 0) {
            long thuNhapBac5 = Math.min(doanhSo, 1500);
            tienThuong += thuNhapBac5 * 0.06;
            doanhSo -= thuNhapBac5;
        }

        if (doanhSo > 0) {
            tienThuong += doanhSo * 0.07;
        }

        System.out.printf("%.3f\n", tienThuong);
    }
}
