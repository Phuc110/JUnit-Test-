public class Q2 {
    
}
