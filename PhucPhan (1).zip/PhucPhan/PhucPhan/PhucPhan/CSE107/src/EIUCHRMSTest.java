import java.util.Scanner;

public class EIUCHRMSTest {
    public static void main(String[] args) {
        var sc = new Scanner(System.in);
        var sb = new StringBuilder();

        var nOBill = sc.nextInt();
        var totalAll = 0L;

        for (int i = 0; i < nOBill; i++) {
            long billValue = sc.nextLong();
            long total = 0;
            double discount = 0;

            if (billValue <= 2000000) {
                discount = billValue * 0.03;
            } else if (billValue <= 5000000) {
                discount = billValue * 0.04;
            } else if (billValue <= 10000000) {
                discount = billValue * 0.05;
            } else if (billValue <= 20000000) {
                discount = billValue * 0.06;
            } else if (billValue <= 50000000) {
                discount = billValue * 0.07;
            } else if (billValue <= 100000000) {
                discount = billValue * 0.08;
            } else {
                discount = billValue * 0.10;
            }

            total = billValue - (long) discount;

            totalAll += total;
        }

        sb.append(totalAll);
        System.out.println(sb);
    }
}
