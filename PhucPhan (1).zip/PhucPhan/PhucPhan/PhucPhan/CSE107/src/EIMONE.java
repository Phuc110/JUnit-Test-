import java.util.Scanner;

public class EIMONE // Money change

{
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        StringBuilder sb = new StringBuilder();
        int moneyOfBeo = scanner.nextInt();
        int[] currencies = { 20, 10, 5, 1 };
        for (int i = 0; i < currencies.length; i++) {
            int quantity = moneyOfBeo / currencies[i];
            moneyOfBeo = moneyOfBeo % currencies[i];
            if (quantity > 0) {
                sb.append(currencies[i]).append(" ").append(quantity).append("\n");
            }
        }
        System.out.print(sb);

    }
}
