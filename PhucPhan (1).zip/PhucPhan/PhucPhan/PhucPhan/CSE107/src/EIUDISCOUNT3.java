
import java.util.Scanner;

public class EIUDISCOUNT3 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Đọc số tiền ban đầu
        long N = sc.nextLong();

        // Đọc ba ưu đãi
        int onlineDiscount = sc.nextInt();
        int vipDiscount = sc.nextInt();
        int cardDiscount = sc.nextInt();

        // Áp dụng giảm giá theo từng điều kiện
        if (onlineDiscount == 1) {
            N = (long) (N * 0.98); // Giảm 2% cho mua hàng online
        }

        if (vipDiscount == 1) {
            N = (long) (N * 0.98); // Giảm 2% cho thành viên VIP
        }

        if (cardDiscount == 1) {
            N = (long) (N * 0.98); // Giảm 2% cho thẻ SuperSaiyan Card
        }

        // In ra số tiền sau khi giảm giá
        System.out.println(N);
    }
}
