import java.util.Scanner;

public class EIUGRADE {
    static Scanner sc= new Scanner(System.in);
public static void main(String[] args) {
    int numberOfCourses= sc.nextInt();
    for (int i = 0; i < numberOfCourses; i++) {
        int studentId= sc.nextInt();
        int subjectCode= sc.nextInt();
        double score=sc.nextDouble();
    }
}
static class Student {
    int studentId;
    int subjectCode;
    double score=0.0;
    public Student(int studentId, int subjectCode, double score) {
        this.studentId = studentId;
        this.subjectCode = subjectCode;
        this.score = score;
    }
    


    
}

    
}

