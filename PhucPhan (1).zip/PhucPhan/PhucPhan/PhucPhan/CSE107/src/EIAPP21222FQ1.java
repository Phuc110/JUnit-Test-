import java.util.Scanner;

public class EIAPP21222FQ1 {
    public static void main(String[] args) {
        Scanner rd = new Scanner(System.in);

        double[] rates = { 3.90, 3.92, 3.95, 3.99, 4.04, 5.54, 5.72, 5.92, 6.14, 6.38, 6.64, 6.92 };

        double amountOfMoney = rd.nextDouble();
        int month = rd.nextInt();
        int years = month / 12;
        int months = month % 12;
        if (years > 0) {
            amountOfMoney = amountOfMoney * Math.pow(1 + rates[11] / 100, years);

        }
        if (months > 0) {
            amountOfMoney *= (1 + rates[months - 1] / 100 / 12 * months);
        }

        System.out.println(Math.round(amountOfMoney));

    }
}
