import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import java.util.StringTokenizer;

public class EIUBIRTH {
    static InputReader rd = new InputReader(System.in);
    static StringBuilder sb = new StringBuilder();

    public static void main(String[] args) {
        long numberOfTestcases = rd.nextInt();
        for (int i = 0; i < numberOfTestcases; i++) {

            long blueGift = rd.nextInt();
            long redGift = rd.nextInt();
            long priceOfBlueGift = rd.nextInt();
            long priceOfRedGift = rd.nextInt();
            long priceToTranferGift = rd.nextInt();
            long minPriceToBuyBlueGift = Math.min(priceOfBlueGift, priceOfRedGift + priceToTranferGift);
            long minPriceToBuyRedGift = Math.min(priceOfRedGift, priceOfBlueGift + priceToTranferGift);
            long total = ((blueGift * minPriceToBuyBlueGift) + (redGift * minPriceToBuyRedGift));

            System.out.println(total);
        }
    }

    static class InputReader {
        StringTokenizer tokenizer;
        BufferedReader reader;
        String token;
        String temp;

        public InputReader(InputStream stream) {
            tokenizer = null;
            reader = new BufferedReader(new InputStreamReader(stream));
        }

        public InputReader(FileInputStream stream) {
            tokenizer = null;
            reader = new BufferedReader(new InputStreamReader(stream));
        }

        public String nextLine() throws IOException {
            return reader.readLine();
        }

        public String next() {
            while (tokenizer == null || !tokenizer.hasMoreTokens()) {
                try {
                    if (temp != null) {
                        tokenizer = new StringTokenizer(temp);
                        temp = null;
                    } else {
                        tokenizer = new StringTokenizer(reader.readLine());
                    }
                } catch (IOException e) {
                }
            }
            return tokenizer.nextToken();
        }

        public double nextDouble() {
            return Double.parseDouble(next());
        }

        public int nextInt() {
            return Integer.parseInt(next());
        }

        public long nextLong() {
            return Long.parseLong(next());
        }
    }
}
