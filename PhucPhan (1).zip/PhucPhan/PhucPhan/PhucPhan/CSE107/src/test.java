import java.util.Scanner;

public class test {
    public static void main(String[] args) {
        var sc = new Scanner(System.in);
        var sb = new StringBuilder();
        long[] money = { 2000000, 5000000, 10000000, 20000000, 50000000, 100000000, 200000000, Long.MAX_VALUE };
        double[] rate = { 3, 4, 5, 6, 7, 8, 9, 10 };
        var nOBill = sc.nextInt();
        var total = 0;
        var discunt = 0;
        var totalAll = 0;
        long[] valueOfBill = new long[nOBill];
        for (var i = 0; i < nOBill; i++) {
            valueOfBill[i] = sc.nextLong();
            if (valueOfBill[i] <= money[i]) {
                discunt += valueOfBill[i] * (rate[i] / 100);
                total += valueOfBill[i] - discunt;
                totalAll += total;

            }
            

        }
        sb.append(totalAll);
        System.out.println(sb);

    }
}