import java.util.Scanner;

public class EIUSALES {
    public static void main(String[] args) {
        var sc = new Scanner(System.in);
        var sb = new StringBuilder();
        var saleVolume = sc.nextInt();
        long[] money = { 0, 20, 50, 200, 500, 2000, Long.MAX_VALUE };
        double[] rate = { 0, 2, 3, 4, 5, 6, 7 };
        var bonusMoney = 0.0;
        for (int i = 1; i < money.length; i++) {
            var level = Math.min(saleVolume, money[i] - money[i - 1]);
            bonusMoney += level * (rate[i] / 100);
            saleVolume -= level;
        }
        System.out.printf("%.2f\n", bonusMoney);
    }
}
