import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;

class IncomeTaxCalculator {

    public static void main(String[] args) throws IOException {

        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        long salary = Long.parseLong(reader.readLine());

        long personalRelief = 9000000;

        long taxableIncome = salary - personalRelief;

        long[] brackets = { 5000000, 10000000, 18000000, 32000000, 52000000, 80000000, Long.MAX_VALUE };
        int[] rates = { 5, 10, 15, 20, 25, 30, 35 };

        long tax = 0;
        long previousBracketLimit = 0;

        for (int i = 0; i < brackets.length; i++) {
            if (taxableIncome > previousBracketLimit) {

                long currentBracketLimit = brackets[i];

                long amountInBracket = Math.min(taxableIncome, currentBracketLimit) - previousBracketLimit;

                tax += (amountInBracket * rates[i]) / 100;

                previousBracketLimit = currentBracketLimit;
            } else {
                break;
            }
        }

        System.out.println(tax);
    }
}
