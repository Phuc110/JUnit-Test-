import java.util.Scanner;

public class EIMEMCARD {
    public static void main(String[] args) {
        var sc = new Scanner(System.in);
        var sb = new StringBuilder();
        var nOItems = sc.nextInt();
        long[] prices = new long[nOItems];
        for (int i = 0; i < nOItems; i++) {
            prices[i] = sc.nextLong();

        }
        var totalPurchase = 0;
        for (int i = 0; i < nOItems; i++) {
            long price = prices[i];
            double discountPercentage = 0;
            if (totalPurchase >= 200000000) {
                discountPercentage = 7;
            } else if (totalPurchase >= 50000000) {
                discountPercentage = 5;
            } else if (totalPurchase >= 20000000) {
                discountPercentage = 3;
            } else if (totalPurchase >= 1000000) {
                discountPercentage = 2;
            }
            double discount = (price * discountPercentage) / 100;
            totalPurchase += price;
            sb.append(discount).append(" ");
        }
        System.out.println(sb);
    }
}
