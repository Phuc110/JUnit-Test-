import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import java.util.StringTokenizer;

class EIDISCOUNT2 {
    static InputReader rd = new InputReader(System.in);
    static StringBuilder sb = new StringBuilder();

    public static void main(String[] args) {
        long N = rd.nextLong();
        long[] amountOfMoney = { 5000000, 20000000, 100000000, 300000000, 600000000, 900000000, Long.MAX_VALUE };
        long[] discountRate = { 3, 5, 7, 10, 12, 15 };
        double discount = 0.0;
        for (int i = 0; i < amountOfMoney.length; i++) {
            if (N >= amountOfMoney[i]) {
                discount += ((Math.min(N, amountOfMoney[i + 1]) - amountOfMoney[i]) * discountRate[i]) / 100.0;
            } else {
                break;
            }
        }
        sb.append(Math.round(N - discount)).append('\n');
        System.out.println(sb);

    }

    static class InputReader {
        StringTokenizer tokenizer;
        BufferedReader reader;
        String token;
        String temp;

        public InputReader(InputStream stream) {
            tokenizer = null;
            reader = new BufferedReader(new InputStreamReader(stream));
        }

        public InputReader(FileInputStream stream) {
            tokenizer = null;
            reader = new BufferedReader(new InputStreamReader(stream));
        }

        public String nextLine() throws IOException {
            return reader.readLine();
        }

        public String next() {
            while (tokenizer == null || !tokenizer.hasMoreTokens()) {
                try {
                    if (temp != null) {
                        tokenizer = new StringTokenizer(temp);
                        temp = null;
                    } else {
                        tokenizer = new StringTokenizer(reader.readLine());
                    }
                } catch (IOException e) {
                }
            }
            return tokenizer.nextToken();
        }

        public double nextDouble() {
            return Double.parseDouble(next());
        }

        public int nextInt() {
            return Integer.parseInt(next());
        }

        public long nextLong() {
            return Long.parseLong(next());
        }
    }
}
