import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

class EISCHSH {
 public static void main(String[] args) {
       var sc = new Scanner(System.in);
        var sb = new StringBuilder();
        int numberOfStudents = sc.nextInt();
        int numberOfScholarships = sc.nextInt();
        List<Student> students = new ArrayList<>();
        for (int i = 0; i < numberOfStudents; i++) {
            long id = sc.nextLong();
            String name = sc.next();
            int numberOfCourses = sc.nextInt();
            Student st = new Student(id, name);
            for (int j = 0; j < numberOfCourses; j++) {
                int grade = sc.nextInt();
                st.addGrade(grade);
            }
            st.calcGPA();
            students.add(st);
        }

        students.sort((s1, s2) -> {
            if (s1.avg == s2.avg) {
                return Long.compare(s1.studentId, s2.studentId);
            }
            return Double.compare(s2.avg, s1.avg);
        });

     
        for (int i = 0; i < numberOfScholarships; i++) {
            int rank = 1;
            if ((i > 0) && Double.compare(students.get(i).avg, students.get(i - 1).avg) != 0) {
                rank += i;
            }
            sb.append(rank + " ").append(students.get(i).Output());

        }
        System.out.println(sb);
    }

    public static class Student {
        public long studentId;
        public String studentName;
        public ArrayList<Integer> studentGrade = new ArrayList<>();
        public double totalGrade = 0;
        public double avg;

        public Student(long studentId, String name) {
            this.studentName = name;
            this.studentId = studentId;
        }

        public void addGrade(int grade) {
            if (grade >= 50) {
                this.studentGrade.add(grade);
                totalGrade += grade;
            }
        }

        public void calcGPA() {
            if (studentGrade.size() > 0) {
                avg = totalGrade / studentGrade.size();
            }
        }

        public String Output() {
            StringBuilder sb = new StringBuilder();
            sb.append(studentId + " ").append(studentName + " ").append(Math.round(avg) + "\n");
            return sb.toString();
        }
    }

}
