
import java.util.Scanner;

class LinkedList<T extends Number> {
    static int length = 0;

    static private class LinkedNode<U extends Number> {
        U number;
        LinkedNode<U> next;

        public LinkedNode(U number) {
            this.number = number;
        }
    }

    LinkedNode<T> head = null;

    public void insertAt(int index, T number) {
        LinkedNode<T> target = new LinkedNode<>(number);
        if (index == 0) {
            target.next = head;
            head = target;
            length++;

        }
    }

    /**
     * @return null if index is out of range
     */
    public T getAt(int index) {
        if (index < 0 || index >= length)
            return null;
        LinkedNode<T> target = head;
        for (int i = 0; i < index; i++) {
            target = target.next;
        }

        return (T) target.number;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        StringBuilder sb = new StringBuilder();

        LinkedList<Integer> linkedList = new LinkedList<Integer>();
        sc.nextInt();
        int m = sc.nextInt();
        for (int i = 0; i < m; i++) {
            String command = sc.next();
            if (command.equals("insertAt")) {
                int index = sc.nextInt();
                int number = sc.nextInt();
                linkedList.insertAt(index, number);
            } else {
                int a = sc.nextInt();
                System.out.println(linkedList.getAt(a));

            }

        }

    }

}
