import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

class EIUGRDSA {
    public static void main(String[] args) {
        var sc = new Scanner(System.in);
        var sb = new StringBuilder();
        var numberOfStudents = sc.nextInt();
        var numberOfProblems = sc.nextInt();
        var numberOfSubmissions = sc.nextInt();
        Map<Integer, Student> stuMap = new HashMap<>();
        for (int i = 0; i < numberOfStudents; i++) {
            int stuID = sc.nextInt();
            Student student = new Student(stuID, numberOfProblems);
            stuMap.put(stuID, student);
        }
        for (int i = 0; i < numberOfProblems; i++) {
            int problem = sc.nextInt();
        }

        for (int i = 0; i < numberOfSubmissions; i++) {
            int stuID = sc.nextInt();
            int codeProblem = sc.nextInt();
            int score = sc.nextInt();
            if (stuMap.get(stuID).scores.containsKey(codeProblem)) {
                if (stuMap.get(stuID).scores.get(codeProblem) < score) {
                    stuMap.get(stuID).Calculate(score, codeProblem);
                    stuMap.get(stuID).scores.replace(codeProblem, score);
                }
            } else {
                stuMap.get(stuID).scores.put(codeProblem, score);
                stuMap.get(stuID).CalculateSumNew(score);
            }
        }

        List<Integer> listKey = new ArrayList<>(stuMap.keySet());
        Collections.sort(listKey);
        for (Integer i : listKey) {
            sb.append(stuMap.get(i).toString()).append("\n");
        }
        System.out.println(sb);
    }

    public static class Student {
        int id;
        Map<Integer, Integer> scores = new HashMap<>();
        double sum;
        double average;
        int problem;

        public Student(int id, int numProblem) {
            this.id = id;
            this.problem = numProblem;
        }

        public void Calculate(int score, int codeProblem) {
            sum += score;
            sum -= scores.get(codeProblem);
            average = sum / problem;
        }

        public void CalculateSumNew(int score) {
            sum += score;
            average = sum / problem;
        }

        public String toString() {
            return id + " " + (long) average;
        }

    }

}
