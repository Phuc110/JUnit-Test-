import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

class EISTULI {
    public static void main(String[] args) {
        var sc = new Scanner(System.in);
        var sb = new StringBuilder();
        int numberOfStudents = sc.nextInt();
        int numberOfCourses = sc.nextInt();
        List<Student> students = new ArrayList<>();
        for (int i = 0; i < numberOfStudents; i++) {
            int id = sc.nextInt();
            String name = sc.next();
            int courseNumber = sc.nextInt();
            Student student = new Student(id, name);
            for (int j = 0; j < courseNumber; j++) {
                int grade = sc.nextInt();
                student.addGrade(grade);
            }
            student.calcAvg();
            students.add(student);
        }

        students.sort((s1, s2) -> {
            int compare = Double.compare(s2.avg, s1.avg);
            return compare;
        });

        if (students.size() <= numberOfCourses) {
            for (Student student : students) {
                sb.append(student.Output());
            }
        } else {
            double ranking = students.get(numberOfCourses - 1).avg;
            if (Double.compare(ranking, students.get(numberOfCourses).avg) != 0) {
                for (int i = 0; i < numberOfCourses; i++) {
                    sb.append(students.get(i).Output());
                }
            } else {
                for (int i = 0; i < numberOfCourses; i++) {
                    if (Double.compare(ranking, students.get(i).avg) == 0) {
                        break;
                    } else {
                        sb.append(students.get(i).Output());
                    }
                }
            }
        }
        System.out.println(sb);
    }

    static class Student {
        int studentID;
        String name;
        long totalGrade = 0;
        long credit = 0;
        double avg = 0;

        public Student(int stID, String name) {
            this.studentID = stID;
            this.name = name;
        }

        public void addGrade(int grade) {
            if (grade >= 50) {
                totalGrade += grade;
                credit += 4;
            }
        }

        public void calcAvg() {
            if (credit > 0) {
                avg = (double) totalGrade / (credit / 4);
            } else {
                avg = 0;
            }
        }

        public String Output() {
            StringBuilder sb = new StringBuilder();
            sb.append(studentID + " ").append(name + " ").append(Math.round(avg) + " ").append(credit + "\n");
            return sb.toString();
        }
    }

}
