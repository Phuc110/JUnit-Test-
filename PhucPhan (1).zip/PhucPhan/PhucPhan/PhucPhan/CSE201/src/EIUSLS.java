import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

class EIUSLS {
    public static void main(String[] args) {
        var sc = new Scanner(System.in);
        var sb = new StringBuilder();
        int numberOfStudents = sc.nextInt();
        List<Student> studentList = new ArrayList<>();

        for (int i = 0; i < numberOfStudents; i++) {
            String name = sc.next();
            int numberOfCourses = sc.nextInt();
            Student student = new Student(name, numberOfCourses);
            for (int j = 0; j < numberOfCourses; j++) {
                int grade = sc.nextInt();
                student.addGrade(grade);
            }
            student.average();
            studentList.add(student);
        }

        studentList.sort((s1, s2) -> {
            int compare = Double.compare(s2.avg, s1.avg);
            return compare;
        });

        if (studentList.size() >= 2) {
            for (int i = 0; i < 2; i++) {
                System.out.println(studentList.get(i).name);
            }
        } else {
            for (int i = 0; i < studentList.size(); i++) {
                System.out.println(studentList.get(i).name);
            }
        }
    }

    public static class Student {
        public String name;
        public int numberOfCourses;
        public double avg;
        public int totalGrade;

        public Student(String name, int numberOfCourses) {
            this.name = name;
            this.numberOfCourses = numberOfCourses;
        }

        public void addGrade(int grade) {
            totalGrade += grade;
        }

        public void average() {
            avg = (double) totalGrade / numberOfCourses;
        }

    }
}
