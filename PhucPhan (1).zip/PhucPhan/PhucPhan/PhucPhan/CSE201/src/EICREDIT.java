import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class EICREDIT {
    static Scanner rd = new Scanner(System.in);

    public static void main(String[] args) {
        StringBuilder result = new StringBuilder();
        int numberOfStudents = rd.nextInt();
        List<Student> students = new ArrayList<>();

        for (int i = 0; i < numberOfStudents; i++) {
            String studentName = rd.next();
            int numberOfCourses = rd.nextInt();
            Student student = new Student(studentName);

            for (int j = 0; j < numberOfCourses; j++) {
                int score = rd.nextInt();
                student.addGrade(score);
            }
            students.add(student);
        }

        for (Student student : students) {
            result.append(student).append("\n");
        }

        System.out.print(result);
    }

    static class Student {
        List<Integer> grades = new ArrayList<>();
        String studentId;

        public Student(String studentId) {
            this.studentId = studentId;
        }

        public void addGrade(int grade) {
            if (grade >= 50) {
                grades.add(grade);
            }
        }

        @Override
        public String toString() {
            StringBuilder sb = new StringBuilder();
            sb.append(studentId).append(" ");
            if (grades.isEmpty()) {
                sb.append("0");
            } else {
                int totalCredits = grades.size() * 4;
                sb.append(totalCredits);
            }
            return sb.toString();
        }
    }
}
