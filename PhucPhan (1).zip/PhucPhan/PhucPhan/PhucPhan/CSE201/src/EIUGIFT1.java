import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.StringTokenizer;

public class EIUGIFT1 // Gift Wrapping
{
    static InputReader rd = new InputReader(System.in);
    static StringBuilder sb = new StringBuilder();

    public static void main(String[] args) {
        int n = rd.nextInt();
        int m = rd.nextInt();
        int[] gifts = new int[n];
        int[] paper = new int[m];
        int giftsIndex = 0;
        int paperIndex = 0;
        int count = 0;

        for (int i = 0; i < n; i++) {
            gifts[i] = rd.nextInt();
        }

        for (int i = 0; i < m; i++) {
            paper[i] = rd.nextInt();
        }

        Arrays.sort(gifts);
        Arrays.sort(paper);

        

        while (giftsIndex < gifts.length && paperIndex < paper.length) {
            double waysToSolve = (double) paper[paperIndex]/gifts[giftsIndex];

            if (waysToSolve >= 2 && waysToSolve <= 3) {
                count++;
                giftsIndex++;
                paperIndex++;
            } else if (waysToSolve < 2) {
                paperIndex++;
            } else {
                giftsIndex++;
            }
        }

        sb.append(count);
        System.out.println(sb);
    }

    static class InputReader {
        StringTokenizer tokenizer;
        BufferedReader reader;
        String token;
        String temp;

        public InputReader(InputStream stream) {
            tokenizer = null;
            reader = new BufferedReader(new InputStreamReader(stream));
        }

        public InputReader(FileInputStream stream) {
            tokenizer = null;
            reader = new BufferedReader(new InputStreamReader(stream));
        }

        public String nextLine() throws IOException {
            return reader.readLine();
        }

        public String next() {
            while (tokenizer == null || !tokenizer.hasMoreTokens()) {
                try {
                    if (temp != null) {
                        tokenizer = new StringTokenizer(temp);
                        temp = null;
                    } else {
                        tokenizer = new StringTokenizer(reader.readLine());
                    }
                } catch (IOException e) {
                }
            }
            return tokenizer.nextToken();
        }

        public double nextDouble() {
            return Double.parseDouble(next());
        }

        public int nextInt() {
            return Integer.parseInt(next());
        }

        public long nextLong() {
            return Long.parseLong(next());
        }
    }
}
