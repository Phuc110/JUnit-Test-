import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

class EICREDI2 {
    public static void main(String[] args) {
        var sc = new Scanner(System.in);
        var sb = new StringBuilder();
        int numberOfStudents = sc.nextInt();
        ArrayList<Student> studentList = new ArrayList<>();
        for (int i = 0; i < numberOfStudents; i++) {
            String name = sc.next();
            var numberOfCourses = sc.nextInt();
            Student student = new Student(name);
            for (int j = 0; j < numberOfCourses; j++) {
                var grades = sc.nextInt();
                student.AddGrade(grades);
            }
            student.CalculateGPA();
            studentList.add(student);
        }
        for (Student student : studentList) {
            sb.append(student.toString());
        }
        System.out.println(sb);
    }

    static class Student {
        List<Integer> gradelist = new ArrayList<>();
        String name;

        long totalScore = 0;
        long avg;

        public Student(String name) {
            this.name = name;
        }

        public void AddGrade(int grade) {
            if (grade >= 50) {
                this.gradelist.add(grade);
                totalScore += grade;
            }
        }

        public void CalculateGPA() {
            if (gradelist.size() > 0) {
                avg = totalScore / gradelist.size();
            } else {
                avg = 0;
            }
        }

        @Override
        public String toString() {
            StringBuilder sb = new StringBuilder();
            sb.append(name + " ");
            for (Integer gr : gradelist) {
                sb.append(gr + " ");
            }
            sb.append(avg + "\n");
            return sb.toString();
        }

    }
}