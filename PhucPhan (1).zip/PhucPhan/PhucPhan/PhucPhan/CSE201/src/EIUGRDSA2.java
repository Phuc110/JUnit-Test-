import java.lang.invoke.VarHandle;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

class EIUGRDSA2 {
    public static void main(String[] args) {
        var sc = new Scanner(System.in);
        var sb = new StringBuilder();
        Map<Integer, Student> listOfStudents = new HashMap<>();
        var numberOfStudents = sc.nextInt();
        var numberOfAssignments = sc.nextInt();
        var totalNumberOfSubmissions  = sc.nextInt();

        for (; numberOfStudents > 0; numberOfStudents--) {
            int id = sc.nextInt();
            listOfStudents.put(id, new Student(id, numberOfAssignments));
        }

        Map<Integer, Boolean> listOfProblems = new HashMap<>();
        for (; numberOfAssignments > 0; numberOfAssignments--) {
            listOfProblems.put(sc.nextInt(), true);
        }

        for (; totalNumberOfSubmissions > 0; totalNumberOfSubmissions--) {
            var studentId = sc.nextInt();
            var problemId = sc.nextInt();
            var grade = sc.nextInt();
            if (!listOfProblems.getOrDefault(problemId, false)) {
                continue;
            }
            Student student = listOfStudents.get(studentId);
            student.newGrade(problemId, grade);
        }

        List<Student> list = new ArrayList<>(listOfStudents.values());
        list.sort((s1, s2) -> {
            if (s1.average != s2.average) {
                return s2.average - s1.average;
            } else if (s1.submission != s2.submission) {
                return s1.submission - s2.submission;
            } else {
                return s1.id - s2.id;
            }
        });
        for (Student s : list) {
            sb.append(s.id).append(" ").append(s.average).append(" ").append(s.submission).append("\n");
        }

        System.out.println(sb);
    }

    static class Student {

        int id;
        int totalProblems;
        int sum = 0;
        int submission = 0;
        Map<Integer, Integer> listFinishedProblem = new HashMap<>();
        int average;

        public Student(int id, int totalProblems) {
            this.id = id;
            this.totalProblems = totalProblems;
        }

        public void newGrade(int problemId, int grade) {
            int oldGrade = listFinishedProblem.getOrDefault(problemId, 0);
            this.sum += Math.max(grade, oldGrade) - oldGrade;
            listFinishedProblem.put(problemId, Math.max(oldGrade, grade));
            this.submission++;
            average();
        }

        public void average() {
            this.average = (int) Math.floor(this.sum * 1.0 / totalProblems);
        }

        @Override
        public String toString() {
            return "Student [id=" + id + ", totalProblems=" + totalProblems + ", sum=" + sum + ", submission="
                    + submission + ", listFinishedProblem=" + listFinishedProblem + ", average=" + average + "]";
        }

    }
}
