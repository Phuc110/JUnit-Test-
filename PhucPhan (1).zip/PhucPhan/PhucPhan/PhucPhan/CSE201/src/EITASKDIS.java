import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.PriorityQueue;
import java.util.Scanner;

class EITASKDIS {
    public static void main(String[] args) {
        var sc = new Scanner(System.in);
        StringBuilder sb = new StringBuilder();
        int nOPeople = sc.nextInt();
        int nOJobs = sc.nextInt();
        List<Integer> tasks = new ArrayList<>();
        for (int i = 0; i < nOJobs; i++) {
            tasks.add(sc.nextInt());
        }
        tasks.sort(Comparator.reverseOrder());

        PriorityQueue<Persons> persons = new PriorityQueue<>((p1, p2) -> {
            int compare = Long.compare(p1.totalHours, p2.totalHours);
            if (compare == 0) {
                compare = Long.compare(p1.personID, p2.personID);
            }
            return compare;
        });

        List<Persons> personList = new ArrayList<>();
        for (int i = 0; i < nOPeople; i++) {
            Persons person = new Persons(i);
            persons.add(person);
            personList.add(person);
        }

        for (int task : tasks) {
            Persons person = persons.poll();
            person.totalHours += task;
            persons.add(person);
        }

        for (Persons person : personList) {
            sb.append(person.totalHours + " ");
        }

        System.out.println(sb);
    }

    public static class Persons {
       long totalHours;
        int personID;

        public Persons(int personID) {
            this.personID = personID;
        }


  
         int studentId;
        int subjectId;
         double aVGrade = 0;
         int subjectCount = 0;
         double totalGrade;

      
        public void addGrade(double grade) {
            subjectCount++;
            totalGrade += grade;
        }

        public void calcAVG() {
            if (subjectCount != 0) {
                aVGrade = ((1.0 * totalGrade) / (subjectCount * 1.0));
            }
        }

        public String Output() {
            StringBuilder sb = new StringBuilder();
            sb.append(studentId + " ").append(Math.round(aVGrade * 1000.0) / 1000.0 + "\n");
            return sb.toString();
        }
    }
}
