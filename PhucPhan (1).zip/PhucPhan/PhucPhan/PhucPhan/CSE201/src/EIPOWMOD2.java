import java.util.Scanner;

class EIPOWMOD2 {
    public static void main(String[] args) {

        var sc = new Scanner(System.in);
        long a = sc.nextLong();
        long b = sc.nextLong();
        long c = sc.nextLong();

        System.out.println(powMod(a, b, c));
    }

    public static long powMod(long a, long b, long c) {
        long result = 1;
        a = a % c;
        while (b > 0) {
            if (b % 2 == 1) {
                result = (result * a) % c;
            }
            a = (a * a) % c;
            b = b / 2;
        }
        return result;
    }
}