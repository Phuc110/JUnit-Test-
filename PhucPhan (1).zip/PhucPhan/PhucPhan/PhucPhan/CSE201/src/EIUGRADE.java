
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

class EIUGRADE {
    static Scanner sc = new Scanner(System.in);
    static StringBuilder sb = new StringBuilder();

    public static void main(String[] args) {
        int numberOfStudents = sc.nextInt();
        var studentMap = new HashMap<Long, Student>();

        for (int i = 0; i < numberOfStudents; i++) {
            long studentId = sc.nextLong();
            int subjectCode = sc.nextInt();
            double grade = sc.nextDouble();

            var student = studentMap.get(studentId);
            if (student == null) {
                student = new Student(studentId);
                studentMap.put(studentId, student);
            }
            student.addGrade(grade);
        }

        var list = new ArrayList<>(studentMap.values());
        list.sort((s1, s2) -> {
            int compare = Double.compare(s2.average, s1.average);
            if (compare == 0) {
                compare = Long.compare(s1.id, s2.id);
            }
            return compare;
        });
        for (Student student : list) {
            sb.append(student.toString()).append("\n");
        }
        System.out.println(sb);

    }

    static class Student {
        long id;
        double totalGrade = 0;
        int totalSubject = 0;
        double average = 0;

        public Student(long id) {
            this.id = id;
        }

        public void addGrade(double grade) {
            totalGrade += grade;
            totalSubject += 1;
            average = (double) totalGrade / totalSubject;
        }

        @Override
        public String toString() {
            return id + " " + (average);
        }
    }
}
