import java.util.*;
import java.io.*;

class EIHPROFIT {
    public static void main(String[] args) {
        var sc = new Scanner(System.in);
        var sb = new StringBuilder();
        int nOProduct = sc.nextInt();
        int topProduct = sc.nextInt();
        List<Products> itemList = new ArrayList<>();
        for (int i = 0; i < nOProduct; i++) {
            int id = sc.nextInt();
            String name = sc.next();
            int price = sc.nextInt();
            int baseprice = sc.nextInt();
            int quantity = sc.nextInt();
            Products products = new Products(id, name, price, baseprice, quantity);
            products.CalcProfit();
            itemList.add(products);
        }

        itemList.sort((s1, s2) -> {
            int compare = Long.compare(s2.profit, s1.profit);
            if (compare == 0) {
                compare = s1.proId - s2.proId;
            }
            return compare;
        });

        long rank = itemList.get(topProduct - 1).profit;
        for (int i = 0; i < itemList.size(); i++) {
            if (itemList.get(i).profit >= rank) {
                sb.append(itemList.get(i).Output());
            } else {
                break;
            }
        }
        System.out.println(sb);
    }

    static class Products {
        int proId;
        String proName;
        int price;
        int basePrice;
        int soldQuantities;
        long profit;

        public Products(int pro_id, String pro_name, int price, int base_price, int sold_quantities) {
            this.proId = pro_id;
            this.proName = pro_name;
            this.price = price;
            this.basePrice = base_price;
            this.soldQuantities = sold_quantities;
        }

        public void CalcProfit() {
            profit = (long) (price - basePrice) * soldQuantities;
        }

        public String Output() {
            StringBuilder sb = new StringBuilder();
            sb.append(proId + " ").append(proName + " ").append(profit + "\n");
            return sb.toString();
        }
    }

}
