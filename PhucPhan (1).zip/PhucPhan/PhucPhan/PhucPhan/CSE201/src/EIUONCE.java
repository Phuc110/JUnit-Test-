import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.StringTokenizer;
public class EIUONCE // Distinct value
{
    static InputReader rd = new InputReader(System.in);
    static StringBuilder sb = new StringBuilder();
    public static void main(String[] args) {
        
        int T = rd.nextInt();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < T; i++) {
            int n = rd.nextInt();
            int[] a = new int[n];
            for (int j = 0; j < n; j++) {
                a[j] = rd.nextInt();

            }
            Arrays.sort(a);
            if (a[0] <= a[1]) {
                sb.append(a[0]).append(" ");
            }
            for (int j = 1; j < n - 2; j++) {
                if (a[j] > a[j - 1] && a[j] <= a[j + 1]) {
                    sb.append(a[j]).append(" ");
                }
                if (a[n - 2] < a[n - 1]) {
                    sb.append(a[n - 1]).append(" ");
                    System.out.println(sb);
                }

            }
        }
    }
    
    static class InputReader {
        StringTokenizer tokenizer;
        BufferedReader reader;
        String token;
        String temp;

        public InputReader(InputStream stream) {
            tokenizer = null;
            reader = new BufferedReader(new InputStreamReader(stream));
        }

        public InputReader(FileInputStream stream) {
            tokenizer = null;
            reader = new BufferedReader(new InputStreamReader(stream));
        }

        public String nextLine() throws IOException {
            return reader.readLine();
        }

        public String next() {
            while (tokenizer == null || !tokenizer.hasMoreTokens()) {
                try {
                    if (temp != null) {
                        tokenizer = new StringTokenizer(temp);
                        temp = null;
                    } else {
                        tokenizer = new StringTokenizer(reader.readLine());
                    }
                } catch (IOException e) {
                }
            }
            return tokenizer.nextToken();
        }

        public double nextDouble() {
            return Double.parseDouble(next());
        }

        public int nextInt() {
            return Integer.parseInt(next());
        }

        public long nextLong() {
            return Long.parseLong(next());
        }
    }
}